#include<stdio.h>
#include<conio.h>
#include<dos.h>
void horizontal(int,int,int,int);
void vertical(int,int,int,int);
void main()
{
int i,j,a,b;
clrscr();
vertical(20,5,18,4);
horizontal(26,5,4,13);
vertical(52,5,18,4);
horizontal(26,19,4,13);

getch();
}
void horizontal(int x,int y,int n,int m)
{
int i,j;
for(i=1;i<=n;i++)
{
gotoxy(x,y);
for(j=1;j<=m;j++)
printf("* ");
delay(150);
y++;
}
//printf("x=%d y=%d\n",x,y);
}
void vertical(int x,int y,int n,int m)
{
int i,j;
for(i=1;i<=n;i++)
{
gotoxy(x,y);
for(j=1;j<=m;j++)
printf("* ");
delay(150);
y++;
}
//printf(" x=%d y=%d\n",x,y);
}